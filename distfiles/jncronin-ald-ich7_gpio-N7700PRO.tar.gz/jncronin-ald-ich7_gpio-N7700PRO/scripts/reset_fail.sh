#!/bin/sh


. ./LED-op

re_create_LED 'Fail' 'red' 25 #0x201
re_create_LED 'Busy' 'orange' 35 #0x201
exit

device=/proc/ich7_gpio

echo 'deleteled busy' > $device
echo 'createled busy red' > $device
echo 'addledcmd busy bright_0 GPO_BLINK 35 0' > $device
echo 'addledcmd busy bright_0 GPIO_USE_SEL 35 1' > $device
echo 'addledcmd busy bright_0 GP_IO_SEL 35 0' > $device
echo 'addledcmd busy bright_0 GP_LVL 35 1' > $device
echo 'addledcmd busy bright_1 GPO_BLINK 35 0' > $device
echo 'addledcmd busy bright_1 GPIO_USE_SEL 35 1' > $device
echo 'addledcmd busy bright_1 GP_IO_SEL 35 0' > $device
echo 'addledcmd busy bright_1 GP_LVL 35 0' > $device
echo 'addledcmd busy get_bright GP_LVL 35 1' > $device
echo 'addledcmd busy blink_on GPO_BLINK 35 1' > $device
echo 'addledcmd busy blink_on GPIO_USE_SEL 35 1' > $device
echo 'addledcmd busy blink_on GP_IO_SEL 35 0' > $device
echo 'addledcmd busy blink_on GP_LVL 35 0' > $device
echo 'addledcmd busy get_blink GPO_BLINK 35 0' > $device
echo 'runledcmd busy bright_0' > $device
echo 'registerled busy' > $device

exit 0

echo 'deleteled pwr_led2' > $device
echo 'createled pwr_led2 blue' > $device
echo 'addledcmd pwr_led2 bright_0 GPO_BLINK 28 0' > $device
echo 'addledcmd pwr_led2 bright_0 GPIO_USE_SEL 28 1' > $device
echo 'addledcmd pwr_led2 bright_0 GP_IO_SEL 28 0' > $device
echo 'addledcmd pwr_led2 bright_0 GP_LVL 28 0' > $device
echo 'addledcmd pwr_led2 bright_1 GPO_BLINK 28 0' > $device
echo 'addledcmd pwr_led2 bright_1 GPIO_USE_SEL 28 1' > $device
echo 'addledcmd pwr_led2 bright_1 GP_IO_SEL 28 0' > $device
echo 'addledcmd pwr_led2 bright_1 GP_LVL 28 1' > $device
echo 'addledcmd pwr_led2 get_bright GP_LVL 28 0' > $device
echo 'addledcmd pwr_led2 blink_on GPO_BLINK 28 1' > $device
echo 'addledcmd pwr_led2 blink_on GPIO_USE_SEL 28 1' > $device
echo 'addledcmd pwr_led2 blink_on GP_IO_SEL 28 0' > $device
echo 'addledcmd pwr_led2 blink_on GP_LVL 28 1' > $device
echo 'addledcmd pwr_led2 get_blink GPO_BLINK 28 0' > $device
echo 'runledcmd pwr_led2 bright_0' > $device
echo 'registerled pwr_led2' > $device


