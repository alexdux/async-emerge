#!/bin/sh

make clean
make && make modules_install
